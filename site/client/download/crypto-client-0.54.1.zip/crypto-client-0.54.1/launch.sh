#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec python3 - "$PWD" "${1:-}" <<'PY'
import os,pathlib,subprocess,sys,shutil,hashlib
project=pathlib.Path(sys.argv[1]); mode=sys.argv[2]
game=None
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        if (p/'comm').read_text().strip().lower()=='vrchat.exe':game=p;break
    except OSError:pass
if not game:sys.exit('Start VRChat through Steam and wait for the main menu, then run this script again.')
env=dict(os.fsdecode(x).split('=',1) for x in (game/'environ').read_bytes().split(b'\0') if b'=' in x)
compat=env.get('STEAM_COMPAT_DATA_PATH')
if not compat:sys.exit('VRChat does not expose its Proton prefix.')
namespace=os.readlink(game/'ns/mnt');instance=None
rows=subprocess.check_output(['flatpak','ps','--columns=instance,application'],text=True).splitlines()
for row in rows:
    ident,app=row.split(None,1)
    if app.strip()!='com.valvesoftware.Steam':continue
    probe=subprocess.run(['flatpak','enter',ident,'/usr/bin/python3','-c','import os,sys;sys.exit(os.readlink("/proc/self/ns/mnt")!=sys.argv[1])',namespace],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    if probe.returncode==0:instance=ident;break
if not instance:sys.exit('Cannot enter the running VRChat container.')
stage=pathlib.Path(compat)/'pfx/drive_c/crypto-client';stage.mkdir(exist_ok=True)
dll_name='CryptoClient-'+hashlib.sha256((project/'dist/CryptoClient.dll').read_bytes()).hexdigest()[:12]+'.dll'
for name in ['CryptoClient.dll','CryptoLaunch.exe','CryptoClient.exe','CryptoStopOverlay.exe']:
    src=project/'dist'/name
    if not src.is_file():sys.exit('Missing '+str(src)+'; run build.sh first.')
    target=stage/(dll_name if name=='CryptoClient.dll' else name)
    if not target.exists() or name!='CryptoClient.dll':shutil.copy2(src,target)
tables=stage/'exports';tables.mkdir(exist_ok=True)
wanted={t.name for t in (project/'dist/exports').glob('*.txt')} if (project/'dist/exports').is_dir() else set()
for t in tables.glob('*.txt'):
    if t.name not in wanted:t.unlink()
for name in wanted:shutil.copy2(project/'dist/exports'/name,tables/name)
print('Staged '+str(len(wanted))+' export table(s) to '+str(tables),flush=True)
print('Matched VRChat runtime. Staged client to '+str(stage),flush=True)
if mode=='--check':sys.exit(0)
helper=r'''
import os,pathlib,sys
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        if (p/'comm').read_text().strip().lower()!='vrchat.exe':continue
        env=dict(os.fsdecode(x).split('=',1) for x in (p/'environ').read_bytes().split(b'\0') if b'=' in x)
        break
    except OSError:continue
else:sys.exit('VRChat exited before launch.')
env.pop('LD_PRELOAD',None)
tools=env.get('STEAM_COMPAT_TOOL_PATHS','').split(':')
proton=next((p+'/proton' for p in tools if pathlib.Path(p+'/proton').is_file()),None)
if not proton:sys.exit('Cannot identify the game Proton version.')
os.environ.clear();os.environ.update(env)
os.chdir(env['STEAM_COMPAT_DATA_PATH']+'/pfx/drive_c/crypto-client')
if sys.argv[1]=='--retire-ui':args=[r'C:\crypto-client\CryptoStopOverlay.exe','--retire']
elif sys.argv[1]=='--stop-overlay':args=[r'C:\crypto-client\CryptoStopOverlay.exe']
elif sys.argv[1]=='--standalone':args=[r'C:\crypto-client\CryptoClient.exe']
else:args=[r'C:\crypto-client\CryptoLaunch.exe','C:\\crypto-client\\'+sys.argv[2]]
os.execv('/usr/bin/python3',['/usr/bin/python3',proton,'runinprefix']+args)
'''
cmd=['flatpak','enter',instance,'/usr/bin/python3','-c',helper,mode,dll_name]
result=subprocess.run(cmd)
sys.exit(result.returncode)
PY
