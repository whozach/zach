Crypto Client 0.54.1

Needs
- Linux
- VRChat on Steam, with Steam installed as a Flatpak (com.valvesoftware.Steam).
  launch.sh only supports the Flatpak Steam.
- python3

Install and run
1. Unzip this folder anywhere.
2. Start VRChat from Steam and wait for the main menu.
3. Run:  bash crypto-client-0.54.1/launch.sh
4. In VRChat, press Insert, open License (key icon, bottom left),
   paste your key (Ctrl+V) and press Activate.

Until a key is active, the client is locked: every feature is off.
Buy a key: https://haunted.ong/client/buy
Support:   support@haunted.ong

After a VRChat update
If the client won't attach after VRChat updates, get the latest download
from your dashboard at https://haunted.ong/client/dashboard, or email support.

Check the files:  cd crypto-client-0.54.1 && sha256sum -c SHA256SUMS
